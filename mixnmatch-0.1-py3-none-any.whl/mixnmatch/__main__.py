import click
import glob
import jinja2
import pathlib
import string
import platform

if not platform.platform().startswith("Linux"):
    click.echo("ERROR! Linux is required to run mixnmatch!")
    exit(1)

def makeSafeFilename(inputFilename):   
  try:
     safechars = string.letters + string.digits + " -_."
     return filter(lambda c: c in safechars, inputFilename)
  except:
     return ""

@click.group()
def cli():
    pass

@click.command()
@click.option(
    "-j",
    "--jinja-midi2mp3-template",
    "midi2mp3_template",
    default="midi2mp3_template.jinja2",
    type=click.Path(dir_okay=False, file_okay=True),
    help="The Jinja2 MIDI2MP3 File template to open.",
)
@click.option(
    "-d",
    "--directory",
    "directory",
    required=True,
    type=click.Path(file_okay=False, dir_okay=True),
    help="Directory to output Sounds",
)
def mixnmatch(midi2mp3_template, directory):
    midis = glob.glob("*.mid")
    sf2s =  glob.glob("*.sf2")
    combs = []
    midi2mp3_template = jinja2.Template(open(midi2mp3_template).read())
    instruction_template = jinja2.Template(open("instructions_template.jinja2").read())
    inst = []

    click.echo("MIDIs: " + str(midis) + "   SF2s: " + str(sf2s))
    
    for sf2 in sf2s:
        combs.append([sf2,[]])
        for midi in midis:
            combs[-1][-1].append(midi)
        del midi
    del sf2
    for font, midilist in combs:
        for midi in midilist:
            file = (pathlib.Path("SoundScripts") / (font[:-4] + "_" + midi[:-4]) ).open(mode="w+")
            file.write(midi2mp3_template.render(data={
                "soundfont": font,
                "dir": directory,
                "midi": midi
            }))
            inst.append({
                "name": font + " & " + midi,
                "file": file.name
            })
            file.close()
    file = open("instructions.txt", "w+")
    file.write(instruction_template.render(instructions=inst))
    click.echo(str(combs))

cli.add_command(mixnmatch)

cli()